import Link from 'next/link'; import AuthForm from '@/components/AuthForm';
export default function Page(){return <main className="auth"><Link href="/">← Lemara OS</Link><section><span className="logo">L</span><h1>Welcome back</h1><p>Sign in to continue your work.</p><AuthForm mode="login"/><small>New here? <Link href="/signup">Create an account</Link></small></section></main>}
