import type { Metadata } from 'next'; import './globals.css';
export const metadata:Metadata={title:'Lemara OS — Personal Command Center',description:'Organize work, projects, reports, people and growth.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
